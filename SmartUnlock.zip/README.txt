01204223 Practicum for Computer Engineering
Department of Computer Engineering Faculty of Engineering Kasetsart University


Project name: Smart Unlock

Developers:

Chonlatas Tasanapreechachai 5910503693
Weeya Weerawatpruchya 5910503847

Files Description:

SourceCode directory 
- SourceCode.ino
Schematicdirectory
- SchematicSmartUnlock.pdf

Hardware:
- 1 Practicum board
- 1 LCD 1602
- 1 Keypad switch
- 1 Micro servo motor
- 1 Passive buzzer
- 1 Vibration sensor


